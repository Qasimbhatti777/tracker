<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Top navbar start  -->
<?php echo $__env->make('user.layouts.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Top navbar End  -->


<div id="layoutSidenav">


<!-- Side navbar Start  -->
    <?php echo $__env->make('user.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Side navbar End  -->

  <div id="layoutSidenav_content">

<!-- Content of The Dashboard Page Start -->
    <?php echo $__env->yieldContent('content'); ?>
<!-- Content of The Dashboard Page End -->


<!-- Footer Start -->

    <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Footer End -->

<?php /**PATH D:\laragon\www\Case Tracker\resources\views/user/layouts/master.blade.php ENDPATH**/ ?>