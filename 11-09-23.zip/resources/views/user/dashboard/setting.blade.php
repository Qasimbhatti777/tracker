@extends('user.layouts.master')
@section('content')
<main>
    <div class="container-fluid px-4">
      <h1 class="mt-4">Setting</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
          <a href="{{ route('dashboard.index') }}">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Settings</li>
      </ol>
      <div class="row">
        <div class="col-xl-3 col-md-6">
          <div class="card bg-primary opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">Active Trackers</div>
            <div class="text-center fw-bold">7</div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-success opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Trackers Included in Subscription
            </div>
            <div class="text-center fw-bold">10</div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-danger opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Trackers over Subscription
            </div>
            <div class="text-center fw-bold">-3</div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-warning opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Current Subscription Tier
            </div>
            <div class="text-center fw-bold">Basic</div>
          </div>
        </div>
      </div>

      <!-- <div class="d-flex justify-content-evenly fw-bold">
        <div>Max # of Trackers</div>
        <div>10</div>
        <div>+ -</div>
      </div> -->
      <div
        class="rounded my-5"
        style="background-color: rgb(238, 237, 237)"
      >
        <div
          class="fw-bold text-dark p-2 rounded-top"
          style="background-color: rgb(189, 187, 187)"
        >
          Set # of Trackers
        </div>
        <div class="p-4">
          <div
            class="d-flex align-items-center justify-content-between gap-1"
          >
            <span class="text-secondary"> Max # of Trackers</span>
            <span class="text-secondary fs-5">10</span>
            <span class="d-flex align-items-center gap-2">
              <button class="btn btn-dark">
                <i class="fa fa-minus" aria-hidden="true"></i>
              </button>
              <button class="btn btn-dark">
                <i class="fa fa-plus" aria-hidden="true"></i>
              </button>
            </span>
          </div>
        </div>
      </div>
      <div
        class="rounded my-5"
        style="background-color: rgb(238, 237, 237)"
      >
        <div
          class="fw-bold text-dark p-2 rounded-top"
          style="background-color: rgb(189, 187, 187)"
        >
          Tracker Notification Email Address(es)
        </div>
        <div class="p-4">
          <div class="d-flex flex-column gap-2">
            <div class="row">
              <div class="col-md-3 d-flex align-items-center gap-1">
                <input
                  type="text"
                  class="form-control shadow-none outline-none border rounded-1"
                  placeholder="Add new email address"
                />
                <button
                  class="btn btn-dark shadow-none outline-none rounded-1"
                >
                  Add
                </button>
              </div>
            </div>
            <ul>
              <li>testmail@gmail.com</li>
              <li>testmailtwo@gmail.com</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- <div class="alert alert-secondary" role="alert">
        <b>Note: </b
        ><span
          >Each item tracked counts towards the total number of cases
          being tracked.</span
        >
      </div> -->
    </div>
  </main>
@endsection
