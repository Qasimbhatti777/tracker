<?php $__env->startSection('content'); ?>

<main>
    <div class="container-fluid px-4">
      <h1 class="mt-4">myDashboard</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active"><?php echo e($user->first_name); ?>'s Dashboard</li>
      </ol>
      <div class="row">
        <div class="col-xl-3 col-md-6">
          <div class="card bg-primary opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">Active Trackers</div>
            <div class="text-center fw-bold"><?php echo e($count); ?></div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-success opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Trackers Included in Subscription
            </div>
            <div class="text-center fw-bold"><?php echo e($include_in_subscription); ?></div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-danger opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Trackers over Subscription
            </div>
            <div class="text-center fw-bold">-3</div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-warning opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Current Subscription Tier
            </div>
            <div class="text-center fw-bold"><?php echo e($plan); ?></div>
          </div>
        </div>
      </div>
      <?php if(session('message')): ?>
      <div class="alert alert-danger">
          <?php echo e(session('message')); ?>

      </div>
        <?php endif; ?>
      <!-- add new Tracking start -->
      <div class="d-flex justify-content-start">
        <a
          href="<?php echo e(route('dashboard.addtracker')); ?>"
          class="btn btn-primary py-2 px-3 my-3 fs-6 opacity-75"
        >
          <i class="fa fa-plus" aria-hidden="true"></i>
          Add New Tracker
        </a>
      </div>

      <!-- table data  -->
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          myTrackers - Active
        </div>
        <div class="card-body">
          <table id="datatablesSimple">
            <thead>
              <tr>
                <th>Case Number</th>
                <th>Case Name</th>
                <th>Tracking</th>
                <th>Last Update</th>
                <th>Action</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>Case Number</th>
                <th>Case Name</th>
                <th>Tracking</th>
                <th>Last Update</th>
                <th>Action</th>
              </tr>
            </tfoot>
            <tbody>
                <?php $__currentLoopData = $trackers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tracker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tracker->case_number); ?></td>
                    <td><?php echo e($tracker->case_name); ?></td>
                    <td>N/A</td>
                    <td><?php echo e($tracker->last_update); ?></td>
                    <td>
                      <a href="<?php echo e(route('dashboard.remove_tracker', ['tracker' => $tracker->id])); ?>">
                        <button class="btn btn-danger">Remove</button>
                      </a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title mx-auto text-danger">ATTENTION !</h4>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <p>
            You are currently Removing a Tracker which will count towards
            your monthly total number of trackers. using more trackers than
            included in your current plan will result in additional charges
            per tracker based on your subscription tier.
          </p>
          <p class="text-center fw-bold">Do you wish to proceed ?</p>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button
            type="button"
            class="rounded-1 btn btn-light"
            data-bs-dismiss="modal"
          >
            No
          </button>
          <button
            type="submit"
            class="rounded-1 btn btn-dark"
            id="submitFormButton"
            data-bs-dismiss="modal"
          >
            Yes
          </button>
        </div>
      </div>
    </div>
  </div>
    <script>
      document.addEventListener("DOMContentLoaded", function () {

    const submitFormButton = document.getElementById("submitFormButton");
    const form = document.querySelector("form");

    submitFormButton.addEventListener("click", function () {
      form.submit(); // Manually submit the form
    });
  });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Case Tracker\resources\views/user/dashboard/index.blade.php ENDPATH**/ ?>