<!DOCTYPE html>
<html>
<head>
    <title>Case Tracker Update</title>
</head>
<body>
    <h1>Case Tracker Update</h1>

    <?php $__currentLoopData = $tracker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $updatedTracker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2>Tracker Details:</h2>
        <ul>
            <li>Case Number: <?php echo e($updatedTracker->case_number); ?></li>
            <li>Case Name: <?php echo e($updatedTracker->case_name); ?></li>
            <li>Last Update: <?php echo e($updatedTracker->last_update); ?></li>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\Case Tracker\resources\views/emails/caseTrackerUpdate.blade.php ENDPATH**/ ?>