<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TackerActive extends Model
{
    use HasFactory;
    protected $table = 'tacker_activies';
    protected $guarded = [];
}
