@extends('user.layouts.master')
@section('content')

<main>
    <div class="container-fluid px-4">
      <h1 class="mt-4">Setting</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
          <a href="{{ route('dashboard.index') }}">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Settings</li>
      </ol>
      <div class="row">
        <div class="col-xl-3 col-md-6">
          <div class="card bg-primary opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">Active Trackers</div>
            <div class="text-center fw-bold" id="trackerCount">{{$activeTracker}}</div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-success opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Trackers Included in Subscription
            </div>
            <div class="text-center fw-bold" id="planValue">{{$include_in_subscription}}</div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-danger opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Trackers over Subscription
            </div>
            <div class="text-center fw-bold">0</div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="card bg-warning opacity-75 text-white mb-4 py-4">
            <div class="text-center fw-bold">
              Current Subscription Tier
            </div>
            <div class="text-center fw-bold">{{$plan}}</div>
        </div>
        </div>
      </div>

      <!-- <div class="d-flex justify-content-evenly fw-bold">
        <div>Max # of Trackers</div>
        <div>10</div>
        <div>+ -</div>
      </div> -->
      <div
        class="rounded my-5"
        style="background-color: rgb(238, 237, 237)"
      >
        <div
          class="fw-bold text-dark p-2 rounded-top"
          style="background-color: rgb(189, 187, 187)"
        >
          Set # of Trackers
        </div>
        {{-- <div class="p-4">
          <div
            class="d-flex align-items-center justify-content-between gap-1"
          >
            <span class="text-secondary"> Max # of Trackers</span>
            <span class="text-secondary fs-5" id="trackerCountAdd">10</span>
            <span class="d-flex align-items-center gap-2">
              <button class="btn btn-dark">
                <i class="fa fa-minus" aria-hidden="true"></i>
              </button>
              <button class="btn btn-dark">
                <i class="fa fa-plus" aria-hidden="true"></i>
              </button>
            </span>
          </div>
        </div> --}}
        <div class="p-4">
          <div class="d-flex align-items-center justify-content-between gap-1">
            <span class="text-secondary"> Max # of Trackers</span>
            <span class="text-secondary fs-5" id="trackerCountAdd">
                <?php if ($tackerActiveMax !== null): ?>
                    <?= $tackerActiveMax->max_active; ?>
                <?php else: ?>
                 10
                <?php endif; ?>
            </span>
         <input type="hidden" id="userId" value={{$authenticated_user->id}}>

            <span class="d-flex align-items-center gap-2">
              <button class="btn btn-dark" id="decrementButton">
                <i class="fa fa-minus" aria-hidden="true"></i>
              </button>
              <button class="btn btn-dark" id="incrementButton">
                <i class="fa fa-plus" aria-hidden="true"></i>
              </button>
            </span>
          </div>
        </div>
      </div>
      <div
        class="rounded my-5"
        style="background-color: rgb(238, 237, 237)"
      >
        <div
          class="fw-bold text-dark p-2 rounded-top"
          style="background-color: rgb(189, 187, 187)"
        >
          Tracker Notification Email Address(es)
        </div>
        <div class="p-4">
          <div class="d-flex flex-column gap-2">
            <div class="row">
              <div class="col-md-3 d-flex align-items-center gap-1">
                <input
                  type="text"
                  class="form-control shadow-none outline-none border rounded-1"
                  placeholder="Add new email address"
                />
                <button
                  class="btn btn-dark shadow-none outline-none rounded-1"
                >
                  Add
                </button>
              </div>
            </div>
            <ul>
              <li>testmail@gmail.com</li>
              <li>testmailtwo@gmail.com</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </main>

@endsection
<!-- Latest compiled and minified JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


<script>
    // Wrap your code in a DOMContentLoaded event listener
    document.addEventListener('DOMContentLoaded', function() {
  // Get a reference to the plus and minus buttons by their class names
  var plusButton = document.querySelector('.btn-dark i.fa-plus').parentElement;
  var minusButton = document.querySelector('.btn-dark i.fa-minus').parentElement;

  // Get a reference to the span elements by their ids
  var trackerCountSpanAdd = document.getElementById('trackerCountAdd');
  var planValueSpan = document.getElementById('planValue');

  // Retrieve the tracker count from localStorage or use a default value
  var trackerCount = localStorage.getItem('trackerCount') || 10;

  // Function to update the tracker count
  function updateTrackerCount() {
    // Check if the tracker count is less than the plan value
    if (trackerCount < parseInt(planValueSpan.textContent)) {
      // Increment the tracker count
      trackerCount++;
      // Update the content of the span element
      trackerCountSpanAdd.textContent = trackerCount;
      // Update the count in localStorage
      localStorage.setItem('trackerCount', trackerCount);
    }
  }

  // Add a click event listener to the plus button
  plusButton.addEventListener('click', updateTrackerCount);

  // Add a click event listener to the minus button
  minusButton.addEventListener('click', function() {
    // Decrement the tracker count, but ensure it doesn't go below 0
    if (trackerCount > 0) {
      trackerCount--;
      // Update the content of the span element
      trackerCountSpanAdd.textContent = trackerCount;
      // Update the count in localStorage
      localStorage.setItem('trackerCount', trackerCount);
    }
  });

  // Initialize the count on page load
  trackerCountSpanAdd.textContent = trackerCount;
});

    // Wrap your code in a DOMContentLoaded event listener

    $(document).ready(function() {
  $('#incrementButton').click(function(event) {
    event.preventDefault();
    // Get the value of the span element with id 'trackerCountAdd'
    var count= document.getElementById('trackerCountAdd').textContent;
    var user = document.getElementById('userId').value;

    $.ajax({
        type: 'GET',
        url: '{{ route('dashboard.active_tracker') }}',
        data: { count: count,user:user},
        success: function(response) {
        },
        error: function() {
         $('.pulse-container').hide();
            $('#responseMessage').text('An error occurred');
        }
    });
});
});
    $(document).ready(function() {
  $('#decrementButton').click(function(event) {
    event.preventDefault();
    // Get the value of the span element with id 'trackerCountAdd'
    var count= document.getElementById('trackerCountAdd').textContent;
    var user = document.getElementById('userId').value;

    $.ajax({
        type: 'GET',
        url: '{{ route('dashboard.active_tracker') }}',
        data: { count: count,user:user},
        success: function(response) {
        },
        error: function() {
         $('.pulse-container').hide();
            $('#responseMessage').text('An error occurred');
        }
    });
});
});

</script>




